# SparseEval Chop Shop repair report

The supplied repository has been repaired and packaged for replacement of
`C:\Users\russe\OneDrive\Desktop\Neutrons\SparseEval-main.zip`.

## Changes

- Corrected the anchor baseline's representative/weight mismatch. A regression
  fixture reproduces the old 0.5 MAE error and gives exactly 0 MAE after repair.
  Real KMeans checks cover duplicate vectors, empty clusters and unique anchors.
- Replaced unbounded retry/fill loops with bounded selection and execution.
  A missing checkpoint now produces a nonzero exit instead of retrying forever.
- Shared validated CLI, dataset loading and trial orchestration across all three
  methods. Script defaults resolve from the repository location. Documented Bash
  anchor arguments are now honored; direct Python entry points work on Windows.
- Added per-trial seeding and provenance. Resumed trials match uninterrupted CPU
  trials in the tested environment. Mismatched or corrupt prior results are
  rejected, saves are atomic, and a lock prevents concurrent result writers.
- Added restricted tensor loading with explicit trusted legacy-pickle opt-in,
  finite matrix and split checks, and support for input without unused metadata.
- Fixed single-row training shapes and checkpoint selection when ranking tau is
  undefined. Undefined test tau remains undefined in result summaries.
- Statistics now include all three methods, both historical tau field spellings,
  arbitrary positive anchor counts, empty/missing results and corrupt-file errors.
- Added dependency pins, tests, package markers, run documentation, generated-file
  exclusions, and source/licensing notes. Original images and citation remain.

## Verification

Final synthetic suite: **15 passed, 1 skipped** (16 tests total), Python 3.12.14,
PyTorch 2.14.0+cpu, NumPy 2.5.3, SciPy 1.18.1, scikit-learn 1.9.0, tqdm 4.70.0.
Tests use real numerical libraries for all three methods, including short MLP
and linear training and KMeans. They cover interrupted/resumed equivalence,
input/config changes, corrupt/legacy results, failed writes, locking, one-row
training, tied rankings, direct-script error exits and statistics.

All ten Python files parse. All four shell scripts parse with tree-sitter-bash
0.25.1. Native Bash integration is **not verified**: Git Bash could not create its
signal pipe in this Windows sandbox (Win32 error 5); the other Bash surface was
access-denied. The initial failing infrastructure check is preserved in the work
order. The final suite reports this optional Windows test as skipped. Run it
with a working `BASH_EXE`, or on Linux, to close that gap.

Real benchmark experiments and GPU execution were not run: data was not supplied
and CUDA was unavailable. These CPU checks do not reproduce the paper's claims.

## Experimental compatibility

The original predictor architectures, challenger/refinement method and default
hyperparameters remain. Results can change because anchor weighting, per-trial
seeding, duplicate handling and the final validation check were corrected.
Existing result lists without configuration provenance remain readable by the
statistics tool but cannot be appended to by the new runner. Select a new
`--output-root` to start a new experimental series.

The original default clusters all model rows, including the test split. It is
explicitly documented as transductive. `--clustering-data train` is an opt-in
held-out alternative with separate result provenance; it changes the protocol.
Undefined validation tau uses finite validation loss for selection, while
undefined test tau is retained as NaN. Statistics show defined/total tau counts.

See the updated README for installation, data shape, smaller synthetic splits,
trusted legacy input, interpreter selection and result resuming.

## Chop Shop provenance

Runtime verification passed for the installed Junkyard Chop Shop 0.7.1 payload.
The verified September 2 yard publication contains 6,564 repositories, with
39 capped entries and four scan errors. No exact SparseEval record or prior
matching job was found. The static repository graph inspected four original
Python files, with external imports unresolved; it was not a runtime analysis.

WeatherReal-Benchmark.git at commit
`68b2f9293d2a0a1b1cedf396cffda34c05a21a14` was inspected, including its MIT license
and weather-evaluation helpers. Those helpers were unsuitable for this tensor
workflow. A mapped causica candidate was no longer present. The bounded search
therefore resulted in **build-new helpers**, reusing the target's existing model
code; no external donor transplant or new donor fit is claimed.

The original source archive had no LICENSE. No project license was invented.
See THIRD-PARTY-NOTICES.md for source and dependency status.

## Recovery and evidence

Original ZIP SHA-256:
`AE2C829CAD9E5EE43768D8798888303C69A2090B2FE34E34F1EE876A6233595A`.

Exact original backup:
`C:\Users\russe\OneDrive\Desktop\GitHub Junkyard\_YARDOFFICE\work-orders\SparseEval-main-20260909-1410\backup\SparseEval-main.zip`.
An additional user-facing copy is delivered as `SparseEval-original.zip`.
To roll back, replace the target ZIP with that original backup.

The work order contains audit, candidate inventory, ordered TODO, execution
contract, applied receipt, test output, syntax/runtime limitations, changes and
archive hashes. Delivered alongside the repaired ZIP are this report, a source
patch and SHA256SUMS.txt. The final deployment receipt confirms replacement
and verifies that the rebuilt archive matches the staged source file by file.
