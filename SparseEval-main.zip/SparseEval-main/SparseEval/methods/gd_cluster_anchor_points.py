import numpy as np
import torch
import random

# --- 依赖 ---
from sklearn.cluster import KMeans
from scipy.stats import kendalltau

# Shared helpers support direct-script and package invocation.
if __package__:
    from .common import load_base_data, validate_anchor_count, cluster_representatives
    from .experiment import run
else:
    from common import load_base_data, validate_anchor_count, cluster_representatives
    from experiment import run

seed = 42

# --- [新] 基于 KMeans 簇大小的锚点和权重生成策略 ---
def generate_anchors_and_weights_kmeans(vectors, num_anchors):
    """Return unique representatives and cluster-aligned weights in bounded time."""
    validate_anchor_count(num_anchors, len(vectors))
    # One k-means++ initialization matches the former n_init='auto' behavior.
    kmeans = KMeans(n_clusters=num_anchors, random_state=random.randint(1, 10000), n_init=1)
    kmeans.fit(vectors)
    return cluster_representatives(vectors, kmeans.labels_, kmeans.cluster_centers_)

# --- [新] 直接使用 KMeans 权重进行评估的函数 ---
def direct_kmeans_evaluation(Y_test, anchor_points, weights):
    """
    直接使用 KMeans 的簇大小作为权重来评估模型性能，不使用MLP。
    """
    print("\n开始使用 KMeans 权重进行直接评估...")

    # 1. 准备输入和目标
    # X_test 是测试集中只包含锚点列的数据
    if len(anchor_points) != len(weights) or not len(anchor_points):
        raise ValueError("anchors and weights must have equal nonzero length")
    if not np.isfinite(weights).all() or np.any(np.asarray(weights) < 0) or np.sum(weights) <= 0:
        raise ValueError("weights must be finite, nonnegative and have positive total")
    X_test = Y_test[:, anchor_points]
    # y_test_true 是测试集中每一行的真实平均值
    y_test_true = Y_test.mean(dim=1)

    # 2. 计算加权平均预测
    weights_tensor = torch.tensor(weights, dtype=torch.float32, device=Y_test.device)
    total_weight = torch.sum(weights_tensor)

    # y_pred = (X_test * weights_tensor).sum(dim=1) / total_weight
    # 使用矩阵乘法提高效率: Y_test[i, anchor_points] * weights -> y_pred[i]
    y_test_pred = torch.matmul(X_test, weights_tensor) / total_weight
    
    # 3. 计算评估指标
    test_mae = torch.abs(y_test_pred - y_test_true).mean().item()
    test_tau, _ = kendalltau(y_test_true.cpu().numpy(), y_test_pred.cpu().numpy())

    print(f"评估完成。")
    return {'best_test_error': test_mae, 'best_test_tau': test_tau}

def main(argv=None):
    return run('anchor_points', generate_anchors_and_weights_kmeans, direct_kmeans_evaluation, argv)


if __name__ == "__main__":
    raise SystemExit(main())
