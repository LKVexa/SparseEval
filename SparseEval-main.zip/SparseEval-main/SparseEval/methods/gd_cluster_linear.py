import numpy as np
import torch
import torch.nn as nn
from tqdm import tqdm
import random

# --- 依赖 ---
from sklearn.cluster import KMeans
from sklearn.metrics import pairwise_distances_argmin_min
from scipy.stats import kendalltau
# Shared helpers support direct-script and package invocation.
if __package__:
    from .common import load_base_data, validate_anchor_count, cluster_representatives
    from .experiment import run
else:
    from common import load_base_data, validate_anchor_count, cluster_representatives
    from experiment import run

seed = 42

# --- MLP 模型定义 ---
class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x); x = self.act(x); x = self.drop(x)
        x = self.fc2(x); x = self.drop(x)
        return x

# --- 代理模型训练函数 ---
def train_proxy_model(X_train, y_train, num_anchors, learning_rate, partial_epochs, device):
    """一个轻量级训练函数，用于在优化循环中快速训练代理MLP。"""
    model = nn.Sequential(
        nn.Linear(num_anchors, 1)
    ).to(device)

    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    
    model.train()
    pbar = tqdm(range(partial_epochs), desc="  - 训练代理模型", leave=False)
    for _ in pbar:
        optimizer.zero_grad()
        loss = criterion(model(X_train).squeeze(-1), y_train)
        loss.backward()
        optimizer.step()
        pbar.set_postfix(loss=f"{loss.item():.6f}")
        
    return model, criterion

# --- [重构后] sparse_eval 锚点生成策略 ---
def generate_anchors_mlp_high(vectors, Y_train, num_anchors, gpu_id, num_refinement_steps=10, partial_epochs=2000, learning_rate=5e-4, **kwargs):
    """
    使用预先分割好的训练集 Y_train 来迭代优化锚点集。
    """
    print(f"正在使用 'sparse_eval' 策略生成 {num_anchors} 个锚点...")
    device = torch.device(f'cuda:{gpu_id}' if gpu_id is not None and torch.cuda.is_available() else 'cpu')
    print(f"sparse_eval 策略将使用设备: {device}")
    
    validate_anchor_count(num_anchors, len(vectors))
    scenario = kwargs.get('scenario', '')
    init_strategy_list = {
        'mmlu': 'random', 
        'winogrande': 'random',
        }
    init_strategy = kwargs.get('init_strategy') or init_strategy_list.get(scenario, 'kmeans')
    if init_strategy not in {'random', 'kmeans'}:
        raise ValueError('init_strategy must be random or kmeans')

    # --- 1. 初始化锚点 ---
    if init_strategy == 'kmeans':
        print("  - [sparse_eval] 使用 KMeans 初始化锚点...")
        kmeans = KMeans(n_clusters=num_anchors, random_state=kwargs.get('random_state', seed), n_init=1)
        kmeans.fit(vectors)
        closest_points_indices, _ = pairwise_distances_argmin_min(kmeans.cluster_centers_, vectors)
        current_anchors = list(np.unique(closest_points_indices))
        selected = set(current_anchors)
        remaining = [i for i in range(vectors.shape[0]) if i not in selected]
        current_anchors.extend(random.sample(remaining, num_anchors - len(current_anchors)))
    else:
        print("  - [sparse_eval] 使用随机策略初始化锚点...")
        current_anchors = random.sample(range(vectors.shape[0]), num_anchors)

    # --- 2. 准备训练数据 (数据已由 main 函数传入) ---
    # 代理模型的目标 y_labels 就是训练集的平均准确率
    y_train_labels = Y_train.mean(dim=1)

    # --- 3. 迭代优化循环 ---
    for step in range(num_refinement_steps):
        print(f"  - [sparse_eval] 开始第 {step+1}/{num_refinement_steps} 轮优化...")
        
        # a. 准备当前锚点的数据并训练代理模型 (使用训练集)
        X_train_data = Y_train[:, current_anchors]
        proxy_model, criterion = train_proxy_model(X_train_data, y_train_labels, len(current_anchors), learning_rate, partial_epochs, device)
        
        # b. 评估现有锚点的重要性 (在训练集上进行)
        proxy_model.eval()
        X_train_data.requires_grad_(True)
        proxy_model.zero_grad()
        predictions = proxy_model(X_train_data).squeeze(-1)
        loss = criterion(predictions, y_train_labels)
        loss.backward()
        
        importance_scores = torch.abs(X_train_data.grad).mean(dim=0)
        X_train_data.requires_grad_(False)
        
        weakest_idx_in_anchors = torch.argmin(importance_scores).item()
        anchor_to_remove = current_anchors[weakest_idx_in_anchors]

        # c. 寻找最佳“挑战者”列 (在训练集上进行)
        with torch.no_grad():
            all_predictions = proxy_model(X_train_data).squeeze(-1)
            error_vector = all_predictions - y_train_labels
            
            Y_train_centered = Y_train - 0.5
            potential_scores = torch.abs(Y_train_centered.T @ error_vector)
            
            potential_scores[current_anchors] = -1.0
            challenger_anchor = torch.argmax(potential_scores).item()

        print(f"    - 交换锚点: {anchor_to_remove} (影响力: {importance_scores[weakest_idx_in_anchors]:.4f}) -> {challenger_anchor} (潜力: {potential_scores[challenger_anchor]:.4f})")

        # d. 执行替换
        if challenger_anchor not in current_anchors:
            current_anchors[weakest_idx_in_anchors] = challenger_anchor
    
    print("sparse_eval 策略执行完毕。")
    return current_anchors

# --- [重构后] MLP 评估函数 ---
def gradient_descent_mlp_evaluation(Y_train, Y_valid, Y_test, anchor_points, learning_rate, num_epochs, patience, gpu_id, *, scenario='', validation_interval=500):
    """使用预先分割好的数据集和最终的锚点集来训练和评估MLP模型。"""
    print("\n开始使用最终的锚点集训练和评估MLP模型...")
    device = torch.device(f'cuda:{gpu_id}' if gpu_id is not None and torch.cuda.is_available() else 'cpu')
    print(f"最终评估将使用设备: {device}")

    # --- 1. 准备输入和目标 (数据已提前分割好并传入) ---
    X_train, X_valid, X_test = Y_train[:, anchor_points], Y_valid[:, anchor_points], Y_test[:, anchor_points]
    y_train, y_valid, y_test = Y_train.mean(dim=1), Y_valid.mean(dim=1), Y_test.mean(dim=1)

    # --- 2. 定义MLP模型 ---
    model = nn.Sequential(
        nn.Linear(len(anchor_points), 1)
    ).to(device)
    vlm_dataset_list = [
        'ai2d', 'blink', 'ccbench', 'mmmu', 'mmtbench', 'realworldqa', 
    ]
    llm_dataset_list = [
        'arc', 'gsm8k', 'hellaswag', 'mmlu', 'truthfulqa', 'winogrande'
    ]
    if scenario in vlm_dataset_list:
        print("is_vlm = True")
        model = nn.Sequential(
            nn.Linear(len(anchor_points), 32), nn.GELU(), nn.Dropout(0.1),
            # nn.Linear(128, 64), nn.GELU(), nn.Dropout(0.1),
            # nn.Linear(64, 32), nn.GELU(), nn.Dropout(0.1),
            nn.Linear(32, 1), nn.Sigmoid()
        ).to(device)
    
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    # --- 3. 训练与早停 ---
    patience_counter = 0
    best_valid_loss = float('inf')
    best_test_error = float('inf')
    best_valid_tau = -2.0
    best_test_tau = -2.0

    for epoch in tqdm(range(num_epochs), desc="最终模型训练"):
        model.train()
        optimizer.zero_grad()
        
        predictions = model(X_train).squeeze(-1)
        loss = criterion(predictions, y_train)
        
        loss.backward()
        optimizer.step()
        
        if epoch % validation_interval == 0 or epoch == num_epochs - 1:
            model.eval()
            with torch.no_grad():
                pred_valid = model(X_valid).squeeze(-1)
                valid_loss = criterion(pred_valid, y_valid)
                valid_tau, _ = kendalltau(y_valid.cpu().numpy(), pred_valid.cpu().numpy())
                
                # A tied/constant ranking has undefined tau; select by finite loss then.
                if (np.isfinite(valid_loss.item()) and valid_loss <= best_valid_loss
                        and (not np.isfinite(valid_tau) or not np.isfinite(best_valid_tau)
                             or valid_tau >= best_valid_tau)):
                    best_valid_loss = valid_loss
                    best_valid_tau = valid_tau
                    
                    pred_test = model(X_test).squeeze(-1)
                    best_test_error = torch.abs(pred_test - y_test).mean()
                    test_tau, _ = kendalltau(y_test.cpu().numpy(), pred_test.cpu().numpy())
                    best_test_tau = test_tau
                    
                    patience_counter = 0
                else:
                    patience_counter += 1
                
                if patience_counter >= patience:
                    print(f"\n早停触发于 Epoch {epoch}。")
                    break
    
    if best_test_error != float('inf'):
        print(f"\n训练完成。最佳测试平均绝对误差 (MAE): {best_test_error.item():.4f}, 最佳测试 Kendall's τ: {best_test_tau:.4f}")
        return {'best_test_error': best_test_error.item(), 'best_test_tau': best_test_tau}
    else:
        print("\n训练未收敛或未找到更优模型。")
        return None

def main(argv=None):
    return run('linear', generate_anchors_mlp_high, gradient_descent_mlp_evaluation, argv)


if __name__ == "__main__":
    raise SystemExit(main())
