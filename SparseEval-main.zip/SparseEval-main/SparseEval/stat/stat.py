"""Summarize existing results without running an experiment on import."""

import argparse
import math
from pathlib import Path
import statistics
import sys

if __package__:
    from ..methods.common import REPO_ROOT, load_results
else:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'methods'))
    from common import REPO_ROOT, load_results


def main(argv=None):
    parser = argparse.ArgumentParser(description='Summarize SparseEval MAE and Kendall tau')
    parser.add_argument('--root', type=Path, default=REPO_ROOT / 'result_data/main_result')
    parser.add_argument('--methods', nargs='+', default=['sparse_eval', 'linear', 'anchor_points'])
    parser.add_argument('--datasets', nargs='+')
    parser.add_argument('--trust-pickle', action='store_true', help='allow trusted legacy pickle results')
    args = parser.parse_args(argv)
    if not args.root.exists():
        print(f'No results found: {args.root}')
        return 0
    if not args.root.is_dir():
        print(f'Result root is not a directory: {args.root}', file=sys.stderr)
        return 1
    print(f'{"Dataset":<20}{"Method":<18}{"Anchors":<10}{"MAE (%)":<14}{"Tau":<14}{"Runs":<8}Tau defined')
    failed, count = False, 0
    for path in sorted(args.root.glob('*/*/*/main_result.pt')):
        dataset, method, anchors = path.relative_to(args.root).parts[:3]
        if method not in args.methods or (args.datasets and dataset not in args.datasets):
            continue
        if not anchors.isascii() or not anchors.isdigit() or int(anchors) < 1:
            continue
        try:
            records = load_results(path, trust_pickle=args.trust_pickle)
            if not records:
                print(f'Skipping empty results: {path}', file=sys.stderr)
                continue
            mae = statistics.mean(float(row['mae']) for row in records)
            taus = [float(row['kendalls_tau'] if 'kendalls_tau' in row else row['kendalltau']) for row in records]
            defined = [tau for tau in taus if math.isfinite(tau)]
            tau_text = f'{statistics.mean(defined):.4f}' if defined else 'undefined'
            print(f'{dataset:<20}{method:<18}{anchors:<10}{100 * mae:<14.4f}{tau_text:<14}'
                  f'{len(records):<8}{len(defined)}/{len(records)}')
            count += 1
        except Exception as exc:
            print(f'Cannot read {path}: {exc}', file=sys.stderr)
            failed = True
    if not count:
        print('No matching nonempty results.')
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
