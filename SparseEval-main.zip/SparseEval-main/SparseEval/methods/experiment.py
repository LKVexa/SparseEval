"""One bounded, resumable execution path for the original SparseEval methods."""

import math
from pathlib import Path
import sys
import warnings

import numpy as np
import scipy
import sklearn
import torch

if __package__:
    from . import common
else:
    import common


def run(method, generate, evaluate, argv=None):
    args = common.parser_for(method).parse_args(argv)
    try:
        return _run(method, generate, evaluate, args)
    except Exception as exc:
        print(f'SparseEval error: {exc}', file=sys.stderr)
        return 1


def _run(method, generate, evaluate, args):
    if args.seed + args.runs >= 2**63 or args.split_seed + args.runs >= 2**63:
        raise ValueError('seed plus runs must be less than 2**63')
    data_path = args.data_root / f'{args.scenario}.pt'
    data_hash = common.file_sha256(data_path)
    base = common.load_base_data(args.scenario, args.data_root, trust_pickle=args.trust_pickle)
    if common.file_sha256(data_path) != data_hash:
        raise RuntimeError('input changed while being loaded; retry with stable input')
    values = base['Y']
    common.validate_anchor_count(args.num_anchors, values.shape[1])
    split_size = args.split_size or (50 if method == 'linear' and args.scenario in common.VLM_DATASETS else 200)
    training = method != 'anchor_points'
    common.validate_split(len(values), split_size, training=training)
    if not training and args.clustering_data == 'train' and len(values) <= split_size:
        raise ValueError('train-only clustering needs model rows outside the test split')
    use_cuda = args.device != 'cpu' and torch.cuda.is_available()
    if args.device == 'cuda' and not use_cuda:
        raise ValueError('CUDA was requested but is unavailable')
    device = torch.device('cuda:0' if use_cuda else 'cpu')
    gpu_id = 0 if use_cuda else None
    config = {key: value for key, value in vars(args).items()
              if key not in {'runs', 'data_root', 'output_root', 'trust_pickle'}}
    config.update(method=method, split_size=split_size, device=str(device),
                  input_sha256=data_hash, protocol='chop-shop-v1',
                  versions={'numpy': str(np.__version__), 'torch': str(torch.__version__),
                            'scipy': str(scipy.__version__), 'sklearn': str(sklearn.__version__)})
    # Changing the source invalidates resumed trials even without a protocol bump.
    config['source_sha256'] = {path.name: common.file_sha256(path)
                               for path in sorted(Path(__file__).parent.glob('*.py'))}
    result_path = args.output_root / args.scenario / method / str(args.num_anchors) / 'main_result.pt'
    with common.result_lock(result_path):
        records = common.load_results(result_path)
        for index, record in enumerate(records):
            if record.get('config') != config or record.get('trial') != index or record.get('seed') != args.seed + index:
                raise ValueError('saved results have different or legacy configuration; use a new --output-root')
        if len(records) >= args.runs:
            print(f'{len(records)} saved trials already satisfy --runs {args.runs}: {result_path}')
            return 0
        if args.clustering_data == 'all':
            warnings.warn('Clustering uses all model rows, including the test split (original transductive protocol). '
                          'Use --clustering-data train for held-out clustering.', UserWarning)
        for trial in range(len(records), args.runs):
            trial_seed = args.seed + trial
            common.seed_trial(trial_seed)
            # Preserve fixed splits for optimized methods and varying baseline splits.
            split_seed = args.split_seed + (trial if method == 'anchor_points' else 0)
            indices = np.random.default_rng(split_seed).permutation(len(values))
            shuffled = torch.as_tensor(values[indices], dtype=torch.float32, device=device)
            test = shuffled[:split_size]
            if training:
                valid = shuffled[split_size:2 * split_size]
                train = shuffled[2 * split_size:]
            else:
                train = shuffled[split_size:]
            vectors = (base['normalized_vectors'] if args.clustering_data == 'all'
                       else common.normalize_items(train.cpu().numpy()))
            print(f'Trial {trial + 1}/{args.runs}, seed={trial_seed}, device={device}')
            if training:
                anchors = generate(vectors, train, args.num_anchors, gpu_id,
                                   scenario=args.scenario, random_state=trial_seed % (2**32),
                                   num_refinement_steps=args.refinement_steps,
                                   partial_epochs=args.partial_epochs, learning_rate=args.learning_rate)
                result = evaluate(train, valid, test, anchors, args.learning_rate,
                                  args.epochs, args.patience, gpu_id,
                                  scenario=args.scenario, validation_interval=args.validation_interval)
            else:
                anchors, weights = generate(vectors, args.num_anchors)
                result = evaluate(test, anchors, weights)
            if result is None:
                raise RuntimeError('evaluation did not produce a checkpoint; no trial was appended')
            mae, tau = float(result['best_test_error']), float(result['best_test_tau'])
            if not math.isfinite(mae):
                raise RuntimeError('evaluation returned nonfinite MAE; no trial was appended')
            record = {'mae': mae, 'kendalls_tau': tau, 'trial': trial, 'seed': trial_seed,
                      'split_seed': split_seed, 'anchors': [int(i) for i in anchors], 'config': config}
            common.save_results(records + [record], result_path)
            records.append(record)
            print(f'Saved MAE={mae:.6f}, tau={tau:.6f} to {result_path}')
    return 0
