# Third-party and source status

No external donor code was incorporated in this repair. The Junkyard search and
rejected candidates are recorded in the accompanying Chop Shop work order.
The new helpers reuse the supplied SparseEval model and refinement code.

The original archive did not contain a project LICENSE. This repair does not
assign a license to the original source or establish redistribution rights.
The upstream paper citation and original assets remain in README.md.

NumPy, PyTorch, SciPy, scikit-learn and tqdm are installed dependencies, not
vendored source. Their distributions carry their own license and notice files.
