"""Synthetic regressions; no external data or model downloads required."""

import contextlib
import io
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import unittest
from unittest.mock import patch
import uuid
import warnings

import numpy as np
import torch

from SparseEval.methods import common
from SparseEval.methods import gd_cluster_anchor_points as baseline
from SparseEval.methods import gd_cluster_linear as linear
from SparseEval.methods import gd_cluster_mlp as mlp
from SparseEval.methods.experiment import run
from SparseEval.stat import stat

torch.set_num_threads(1)
METHODS = {'anchor_points': baseline, 'linear': linear, 'sparse_eval': mlp}


class LegacyMetadata:
    pass


class SparseEvalTests(unittest.TestCase):
    def setUp(self):
        self.root = common.REPO_ROOT / '.test-tmp' / uuid.uuid4().hex
        self.root.mkdir(parents=True)
        self.data = self.root / 'data'
        self.data.mkdir()
        generator = torch.Generator().manual_seed(80)
        self.matrix = torch.rand(12, 6, generator=generator)
        torch.save({'matrix': self.matrix}, self.data / 'arc.pt')

    def tearDown(self):
        shutil.rmtree(self.root)

    def options(self, method, output, runs=1):
        args = ['arc', '3', '--runs', str(runs), '--split-size', '3', '--device', 'cpu',
                '--data-root', str(self.data), '--output-root', str(output)]
        if method != 'anchor_points':
            args += ['--epochs', '2', '--partial-epochs', '1', '--refinement-steps', '1',
                     '--validation-interval', '1']
        return args

    def call(self, method, output, runs=1, extra=()):
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()), warnings.catch_warnings():
            warnings.simplefilter('ignore')
            return METHODS[method].main(self.options(method, output, runs) + list(extra))

    def result_path(self, output, method):
        return output / 'arc' / method / '3/main_result.pt'

    def test_cluster_order_matches_weights(self):
        vectors = np.array([[10.], [0.], [0.], [0.]], dtype=np.float32)
        anchors, weights = common.cluster_representatives(vectors, np.array([1, 0, 0, 0]), np.array([[0.], [10.]]))
        self.assertEqual(anchors, [1, 0])
        np.testing.assert_array_equal(weights, [3, 1])
        values = torch.tensor([[1., 0., 0., 0.], [0., 1., 1., 1.]])
        result = baseline.direct_kmeans_evaluation(values, anchors, weights)
        self.assertEqual(result['best_test_error'], 0.0)
        self.assertAlmostEqual(result['best_test_tau'], 1.0)
        # The old np.unique sorting produces the wrong prediction on this fixture.
        wrong = baseline.direct_kmeans_evaluation(values, sorted(anchors), weights)
        self.assertEqual(wrong['best_test_error'], 0.5)

    def test_real_kmeans_duplicate_vectors_terminates_with_unique_anchors(self):
        for count in [1, 3, 5]:
            with self.subTest(count=count), warnings.catch_warnings():
                warnings.simplefilter('ignore')
                anchors, weights = baseline.generate_anchors_and_weights_kmeans(np.ones((5, 2)), count)
            self.assertEqual(len(set(anchors)), count)
            self.assertEqual(len(weights), count)
            self.assertEqual(sum(weights), 5)
        with self.assertRaises(ValueError):
            baseline.generate_anchors_and_weights_kmeans(np.ones((5, 2)), 6)

    def test_invalid_matrix_schema_and_values(self):
        bad = [{}, {'matrix': [[1, 2]]}, {'matrix': torch.zeros(2)},
               {'matrix': torch.zeros(2, 0)}, {'matrix': torch.zeros(1, 2)},
               {'matrix': torch.tensor([[0., float('nan')], [1., 2.]])},
               {'matrix': torch.tensor([[0., float('inf')], [1., 2.]])},
               {'matrix': torch.zeros(2, 2, dtype=torch.complex64)}]
        for value in bad:
            with self.subTest(value=str(value)):
                torch.save(value, self.data / 'bad.pt')
                with self.assertRaises(ValueError):
                    common.load_base_data('bad', self.data)
        torch.save({'matrix': torch.zeros(2, 2, dtype=torch.bool)}, self.data / 'bool.pt')
        self.assertEqual(common.load_base_data('bool', self.data)['Y'].dtype, np.float32)

    def test_safe_load_requires_explicit_trust_for_legacy_object(self):
        torch.save({'matrix': self.matrix, 'models': LegacyMetadata()}, self.data / 'legacy.pt')
        with self.assertRaises(Exception):
            common.load_base_data('legacy', self.data)
        self.assertEqual(common.load_base_data('legacy', self.data, trust_pickle=True)['Y'].shape, (12, 6))

    def test_all_methods_execute_real_training_or_clustering_and_resume(self):
        for name in METHODS:
            with self.subTest(method=name):
                full, resumed = self.root / f'{name}-full', self.root / f'{name}-resumed'
                self.assertEqual(self.call(name, full, 2), 0)
                self.assertEqual(self.call(name, resumed, 1), 0)
                self.assertEqual(self.call(name, resumed, 2), 0)
                actual = common.load_results(self.result_path(resumed, name))
                self.assertEqual(actual, common.load_results(self.result_path(full, name)))
                self.assertEqual([r['seed'] for r in actual], [42, 43])
                before = self.result_path(resumed, name).read_bytes()
                self.assertEqual(self.call(name, resumed, 2), 0)
                self.assertEqual(before, self.result_path(resumed, name).read_bytes())

    def test_resuming_changed_config_or_data_preserves_old_results(self):
        output = self.root / 'results'
        self.assertEqual(self.call('linear', output), 0)
        path = self.result_path(output, 'linear')
        before = path.read_bytes()
        self.assertEqual(self.call('linear', output, 2, ['--learning-rate', '0.01']), 1)
        self.assertEqual(path.read_bytes(), before)
        torch.save({'matrix': self.matrix + .1}, self.data / 'arc.pt')
        self.assertEqual(self.call('linear', output, 2), 1)
        self.assertEqual(path.read_bytes(), before)

    def test_corrupt_and_legacy_results_are_never_silently_reset(self):
        output = self.root / 'results'
        path = self.result_path(output, 'linear')
        path.parent.mkdir(parents=True)
        path.write_bytes(b'corrupt')
        self.assertEqual(self.call('linear', output), 1)
        self.assertEqual(path.read_bytes(), b'corrupt')
        common.save_results([{'mae': .1, 'kendalls_tau': .9}], path)
        before = path.read_bytes()
        self.assertEqual(self.call('linear', output), 1)
        self.assertEqual(path.read_bytes(), before)

    def test_atomic_save_failure_preserves_previous_file(self):
        path = self.root / 'saved.pt'
        common.save_results([{'mae': .1, 'kendalls_tau': .9}], path)
        before = path.read_bytes()
        with patch.object(torch, 'save', side_effect=OSError('simulated write failure')):
            with self.assertRaises(OSError):
                common.save_results([{'mae': .2, 'kendalls_tau': .8}], path)
        self.assertEqual(path.read_bytes(), before)
        self.assertEqual(list(path.parent.glob('.result-*.pt')), [])

    def test_result_lock_excludes_second_writer_and_cleans_up(self):
        path = self.root / 'saved.pt'
        with common.result_lock(path):
            with self.assertRaises(RuntimeError):
                with common.result_lock(path):
                    self.fail('second writer entered')
        self.assertFalse(path.with_suffix('.lock').exists())

    def test_bad_split_and_anchor_counts_fail_without_results(self):
        for name in METHODS:
            for extra in [['--split-size', '20'], ['--split-size', '1']]:
                with self.subTest(method=name, extra=extra):
                    output = self.root / f'bad-{name}'
                    self.assertEqual(self.call(name, output, extra=extra), 1)
                    self.assertFalse(self.result_path(output, name).exists())
        self.assertRaises(ValueError, common.validate_anchor_count, 0, 6)

    def test_single_training_row_and_constant_tau_finish(self):
        torch.save({'matrix': torch.full((7, 6), .5)}, self.data / 'arc.pt')
        for name in ['linear', 'sparse_eval']:
            output = self.root / name
            self.assertEqual(self.call(name, output), 0)
            result = common.load_results(self.result_path(output, name))[0]
            self.assertTrue(math.isfinite(result['mae']))
            self.assertTrue(math.isnan(result['kendalls_tau']))

    def test_train_only_clustering_receives_only_training_rows(self):
        seen = []
        def generate(vectors, train, num_anchors, gpu_id, **kwargs):
            np.testing.assert_allclose(vectors, common.normalize_items(train.cpu().numpy()))
            seen.append(vectors.shape)
            return [0, 1, 2]
        def evaluate(*args, **kwargs):
            return {'best_test_error': .1, 'best_test_tau': .5}
        with contextlib.redirect_stdout(io.StringIO()):
            status = run('linear', generate, evaluate,
                         self.options('linear', self.root / 'training') + ['--clustering-data', 'train'])
        self.assertEqual(status, 0)
        self.assertEqual(seen, [(6, 6)])

    def test_no_checkpoint_ends_instead_of_retrying_forever(self):
        with patch.object(linear, 'gradient_descent_mlp_evaluation', return_value=None) as evaluate:
            self.assertEqual(self.call('linear', self.root / 'none'), 1)
        self.assertEqual(evaluate.call_count, 1)

    def test_statistics_handles_missing_empty_mixed_and_corrupt_results(self):
        output = self.root / 'stats'
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(stat.main(['--root', str(output)]), 0)
        common.save_results([], output / 'arc/linear/2/main_result.pt')
        for name in METHODS:
            common.save_results([{'mae': .1, 'kendalltau': .8}, {'mae': .2, 'kendalls_tau': float('nan')}],
                                output / f'arc/{name}/3/main_result.pt')
        (output / 'arc/linear/notes').mkdir()
        with contextlib.redirect_stdout(io.StringIO()) as stream, contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(stat.main(['--root', str(output)]), 0)
        text = stream.getvalue()
        for name in METHODS:
            self.assertIn(name, text)
        self.assertIn('15.0000', text)
        self.assertIn('1/2', text)
        (output / 'arc/linear/2/main_result.pt').write_bytes(b'corrupt')
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(stat.main(['--root', str(output)]), 1)

    def test_cli_paths_errors_and_nonzero_exit_codes(self):
        env = dict(os.environ, PYTHONUTF8='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
        for name, module in METHODS.items():
            command = [sys.executable, str(Path(module.__file__).resolve())]
            for options, expected in [(['--help'], 0), (['arc'], 2), (['../arc', '3'], 2), (['arc', '0'], 2)]:
                with self.subTest(method=name, args=options):
                    result = subprocess.run(command + options, cwd=self.root, env=env, capture_output=True, timeout=60)
                    self.assertEqual(result.returncode, expected, result.stderr.decode(errors='replace'))
        result = subprocess.run([sys.executable, str(Path(linear.__file__).resolve()), 'missing', '3',
                                 '--data-root', str(self.data)], cwd=self.root, env=env, capture_output=True, timeout=60)
        self.assertEqual(result.returncode, 1)

    def test_shell_runner_honors_anchor_argument_outside_repository(self):
        bash = os.environ.get('BASH_EXE') or (shutil.which('bash') if os.name != 'nt' else None)
        if not bash:
            self.skipTest('set BASH_EXE to a native Bash executable to test shell integration')
        env = dict(os.environ, PYTHON=sys.executable.replace('\\', '/'), PYTHONUTF8='1',
                   OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
        output = self.root / 'shell results'
        for name, module in METHODS.items():
            runner = common.REPO_ROOT / 'SparseEval/run' / (Path(module.__file__).stem + '.sh')
            args = self.options(name, output)
            result = subprocess.run([bash, str(runner).replace('\\', '/')] + args,
                                    cwd=self.root, env=env, capture_output=True, timeout=60)
            self.assertEqual(result.returncode, 0, result.stderr.decode(errors='replace'))
            self.assertEqual(len(common.load_results(self.result_path(output, name))), 1)
            self.assertFalse((output / 'arc' / name / '20').exists())


if __name__ == '__main__':
    unittest.main()
