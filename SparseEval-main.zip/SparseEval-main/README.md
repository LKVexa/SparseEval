<h1 align="center">[ICLR2026] SparseEval: Efficient Evaluation of Large Language Models by Sparse Optimization</h1>

<p align="center">
<a href="https://arxiv.org/abs/2602.07909"><img src="https://img.shields.io/badge/arXiv-2602.07909-b31b1b.svg" alt="arXiv"></a>
<a href="https://huggingface.co/datasets/iridescentttt/SparseEval_preprocess_data"><img src="https://img.shields.io/badge/%F0%9F%A4%97%20Hugging%20Face-SparseEval__preprocess__data-blue" alt="Hugging Face"></a>
</p>

<p align="center">
<a href="#-introduction">📖 Introduction</a> • 
<a href="#-main-results">📊 Main Results</a> • 
<a href="#-getting-started">🚀 Getting Started</a> • 
<a href="#-citation">📜 Citation</a>
</p>

## 📖 Introduction

As large language models (LLMs) continue to scale, evaluating their capabilities on comprehensive benchmarks has become computationally expensive. *SparseEval* is a novel framework that formulates efficient evaluation as a sparse optimization problem.



Key contributions of SparseEval include:
- **Sparsity Discovery**: We reveal that evaluation matrices exhibit inherent sparsity, where a small subset of "anchor" items can effectively represent the entire benchmark.
- **Anchor Optimization**: We introduce a gradient descent-based method to optimize the weights of selected anchor points for accurate performance estimation.
- **Task-Aware Refinement**: We leverage a proxy model to iteratively refine anchor selection, ensuring high relevance to the downstream task.

<p align="center">
  <img src="assets/framework.png" width="90%">
  <br> &nbsp;
  <em>Fig. 2: The overall framework of SparseEval.</em>
</p>


SparseEval enables efficient benchmarking by selecting the most informative samples, achieving a balance between computational efficiency and evaluation reliability.

## 📊 Main Results

### Evaluation Sparsity in LLM Benchmarks
Our analysis of model-item performance matrices reveals distinct clustering patterns (Evaluation Sparsity). As shown in our studies, items within the same cluster exhibit high similarity in model response patterns, allowing us to select representative anchors to predict performance on the full dataset accurately.

<p align="center">
  <img src="assets/motivation.png" width="90%">
  <br> &nbsp;
  <em>Fig. 1: Motivation of SparseEval.</em>
</p>

### Performance Comparison
SparseEval consistently outperforms traditional baseline methods in terms of accuracy-efficiency tradeoffs. As shown in the figure below, our method achieves superior performance across multiple metrics.

<p align="center">
  <img src="assets/results.png" width="98%">
  <br> &nbsp;
  <em>Fig. 3: Main Results of SparseEval.</em>
</p>


- **High Correlation**: Maintains a Kendall’s $\tau > 0.9$ with full benchmark scores while using significantly fewer samples.
- **Low Estimation Error**: Achieves significantly lower Mean Absolute Error (MAE) compared to baselines.
- **Efficiency**: Reduces inference costs by orders of magnitude (e.g., evaluating on only 100 instances) without sacrificing ranking consistency.

We demonstrate robustness across various benchmarks including MMLU, ARC, GSM8K, HellaSwag, TruthfulQA, and Winogrande.

## 🚀 Getting Started

### Local setup and repaired runner

Use Python 3.12 and an isolated environment. The supplied CPU test environment
uses the versions in `requirements.txt`:

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

On Windows, run the Python entry points directly; Bash scripts require Git Bash
or another Bash environment. For GPU use, install the corresponding PyTorch
build for your hardware. CPU tests do not establish GPU reproducibility.

```bash
python SparseEval/methods/gd_cluster_mlp.py gsm8k 100
python SparseEval/methods/gd_cluster_linear.py gsm8k 100
python SparseEval/methods/gd_cluster_anchor_points.py gsm8k 100
python SparseEval/methods/gd_cluster_mlp.py --help
```

Default data and result paths are resolved against the repository location,
including when the Python or Bash script is launched from another directory.
Use `--data-root PATH` and `--output-root PATH` to override them. A Bash runner
honors the optional anchor count; when omitted, it retains the original sweep
(20/40/60/80/100 for baselines, 100 for MLP). `PYTHON` selects its interpreter.

Runs are bounded by `--runs` (default 10 total, including saved trials). Optimized
methods expose `--epochs`, `--partial-epochs`, `--refinement-steps`,
`--learning-rate`, `--patience`, and `--validation-interval`. Patience counts
validation checks. Defaults retain 20,000 final epochs, 2,000 proxy epochs,
10 refinement steps, learning rate 0.0005, patience 30 and 500-epoch validation.

Each result stores anchors, trial and split seeds, input/source hashes, numerical
library versions and effective settings. `--seed` controls per-trial randomness;
`--split-seed` controls row splitting (both default 42). Optimized methods retain
a fixed split across trials; the anchor baseline varies the split per trial.
Resuming with unchanged settings reproduces the per-trial random streams.
Bit-identical behavior across hardware, devices or library versions is not assured.

Existing result files are validated and atomically replaced after each successful
trial. Changed settings/data/source or legacy records without provenance require
a new `--output-root`; old results are not silently discarded. A `.lock` prevents
two writers sharing the same result file. After a killed process, remove that
lock only after confirming that no writer remains active.

**Evaluation protocol:** the original default clusters item vectors using every
model row, including test rows. This is a transductive evaluation, so its metrics
should not be described as independent held-out performance. Use
`--clustering-data train` to fit clustering only on training rows. This option
changes the experimental protocol and needs a separate output root. The anchor
baseline uses all non-test rows for this mode.

The cluster baseline now keeps representatives aligned with their cluster weights.
Duplicate vectors terminate with unique representatives; empty clusters receive
zero weight. These corrections can change results relative to the input archive.
Undefined validation tau (constant/tied rankings) falls back to finite validation
loss for checkpoint selection; undefined test tau stays NaN and is reported as
undefined, never as zero. The final epoch is also checked for validation.

### Data Preparation


Please download the data from Hugging Face:

- **`preprocess_data`** (Necessary): [Download Link](https://huggingface.co/datasets/iridescentttt/SparseEval_preprocess_data). Contains the processed data files ready for evaluation.
- **`benchmark_data`** (Optional): [Download Link](https://huggingface.co/datasets/iridescentttt/SparseEval_benchmark_data). Contains the raw, unprocessed prediction files.

**Supported Datasets**: `arc`, `gsm8k`, `hellaswag`, `mmlu`, `truthfulqa`, `winogrande`.

Place the downloaded folders in the root of the repository. The expected directory structure is:

```
.
├── benchmark_data/    # Raw prediction files (CSV, Optional)
├── preprocess_data/   # Processed data files (Tensor)
└── ...
```

Each `<dataset>.pt` must hold a dictionary with a dense, real, finite PyTorch
tensor under `matrix`, shaped `[models, benchmark_items]`. Optional `models`
metadata is not required. Scores should follow the upstream benchmark's encoding.
The number of anchors must not exceed the item count. The default optimized
LLM split needs at least 401 models (200 test, 200 validation, at least one
training row); the linear VLM split needs 101. For smaller synthetic fixtures,
set `--split-size` (at least 2). The baseline needs at least the test split size.

Tensor files use PyTorch's restricted `weights_only=True` loader by default.
For trusted legacy input files containing additional pickled objects, use
`--trust-pickle`; that explicit option permits executable unpickling. Never use it
for untrusted files. See [PyTorch loading documentation](https://docs.pytorch.org/docs/2.14/generated/torch.load.html).

### Running SparseEval
Execute the evaluation methods using the provided scripts. Experimental parameters (number of anchors, learning rates) can be modified within these scripts.

#### Main Method: SparseEval (MLP-based)
This is the primary method proposed in the paper, utilizing gradient-based optimization with an MLP predictor.
```bash
bash SparseEval/run/gd_cluster_mlp.sh <dataset_name> <num_anchors>
# Example: bash SparseEval/run/gd_cluster_mlp.sh gsm8k 100
```

#### Baselines
We provide several baseline methods for comparison:

**1. Optimization-based Linear Weighting**

Uses gradient descent to optimize weights for interpretable performance prediction.
```bash
bash SparseEval/run/gd_cluster_linear.sh <dataset_name> <num_anchors>
```

**2. Anchor Point Selection**

Selects representative samples and uses cluster sizes as weights.
```bash
bash SparseEval/run/gd_cluster_anchor_points.sh <dataset_name> <num_anchors>
```

### Viewing Results
You can view the aggregated results (Error and Tau) using the provided statistics script:
```bash
python SparseEval/stat/stat.py
```

Statistics include all three methods and any positive anchor count. Use
`--root PATH`, `--methods linear sparse_eval`, or `--datasets gsm8k` to filter.
Missing results and empty lists are handled cleanly; corrupt files are reported
with a nonzero exit code. Both historical tau key spellings are accepted. Tau
averages include only defined values and show the contributing count. Reading
trusted legacy result files can be explicitly enabled with `--trust-pickle`.

See `CHOP-SHOP-REPORT.md` for the applied changes and verification limits.

## 📜 Citation
If you find this work helpful, please cite us.

```bibtex
@article{zhang2026sparseeval,
  title={SparseEval: Efficient Evaluation of Large Language Models by Sparse Optimization},
  author={Zhang, Taolin and Guo, Hang and Lu, Wang and Dai, Tao and Xia, Shu-Tao and Wang, Jindong},
  journal={arXiv preprint arXiv:2602.07909},
  year={2026}
}
```
