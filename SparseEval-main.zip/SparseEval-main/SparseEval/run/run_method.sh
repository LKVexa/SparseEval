#!/usr/bin/env bash
set -euo pipefail
method="$1"
shift
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
python_executable="${PYTHON:-python3}"
if [[ "$#" -eq 0 ]]; then
    printf 'Usage: bash %s.sh <dataset> [num_anchors] [options]\n' "$method" >&2
    exit 2
fi
if [[ "$1" == '--help' || "$1" == '-h' ]]; then
    exec "$python_executable" "$script_dir/../methods/$method.py" --help
fi
scenario="$1"
shift
anchors=(20 40 60 80 100)
if [[ "$method" == 'gd_cluster_mlp' ]]; then
    anchors=(100)
fi
if [[ "$#" -gt 0 && "$1" != --* ]]; then
    anchors=("$1")
    shift
fi
for num_anchors in "${anchors[@]}"; do
    "$python_executable" "$script_dir/../methods/$method.py" "$scenario" "$num_anchors" "$@"
done
