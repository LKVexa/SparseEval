"""Anchor selection and learned evaluation methods."""
