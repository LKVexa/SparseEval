"""Shared input, experiment and result contracts for the three methods."""

import argparse
from contextlib import contextmanager
import hashlib
import math
import os
from pathlib import Path
import random
import re
import tempfile

REPO_ROOT = Path(__file__).resolve().parents[2]
VLM_DATASETS = {'ai2d', 'blink', 'ccbench', 'mmmu', 'mmtbench', 'realworldqa'}


def positive_int(value):
    number = int(value)
    if number <= 0:
        raise argparse.ArgumentTypeError('must be a positive integer')
    return number


def nonnegative_int(value):
    number = int(value)
    if number < 0:
        raise argparse.ArgumentTypeError('must be a nonnegative integer')
    return number


def positive_float(value):
    number = float(value)
    if not math.isfinite(number) or number <= 0:
        raise argparse.ArgumentTypeError('must be finite and positive')
    return number


def scenario_name(value):
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*', value):
        raise argparse.ArgumentTypeError('use a dataset name with letters, digits, _ or -')
    return value


def parser_for(method):
    parser = argparse.ArgumentParser(description=f'SparseEval: {method}')
    parser.add_argument('scenario', type=scenario_name)
    parser.add_argument('num_anchors', type=positive_int)
    parser.add_argument('--data-root', type=Path, default=REPO_ROOT / 'preprocess_data')
    parser.add_argument('--output-root', type=Path, default=REPO_ROOT / 'result_data/main_result')
    parser.add_argument('--runs', type=positive_int, default=10, help='total trials, including saved trials')
    parser.add_argument('--seed', type=nonnegative_int, default=42)
    parser.add_argument('--split-seed', type=nonnegative_int, default=42)
    parser.add_argument('--split-size', type=positive_int, help='test/validation rows; defaults to 200 (50 for linear VLM)')
    parser.add_argument('--device', choices=['auto', 'cpu', 'cuda'], default='auto')
    parser.add_argument('--clustering-data', choices=['all', 'train'], default='all',
                        help='all preserves the original transductive protocol; train excludes test/validation')
    parser.add_argument('--trust-pickle', action='store_true',
                        help='allow executable pickle payloads in trusted legacy input data ONLY')
    if method != 'anchor_points':
        parser.add_argument('--epochs', type=positive_int, default=20000)
        parser.add_argument('--partial-epochs', type=positive_int, default=2000)
        parser.add_argument('--refinement-steps', type=nonnegative_int, default=10)
        parser.add_argument('--learning-rate', type=positive_float, default=5e-4)
        parser.add_argument('--patience', type=positive_int, default=30)
        parser.add_argument('--validation-interval', type=positive_int, default=500)
    return parser


def seed_trial(seed):
    import numpy as np
    import torch
    random.seed(seed)
    np.random.seed(seed % (2**32))
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def load_tensor_file(path, *, trust_pickle=False):
    import torch
    # No automatic fallback to executable unpickling.
    return torch.load(Path(path), map_location='cpu', weights_only=not trust_pickle)


def normalize_items(matrix):
    import numpy as np
    values = np.asarray(matrix, dtype=np.float32)
    if values.min() >= 0 and values.max() <= 1:
        values = 2 * values - 1
    items = values.T
    norms = np.linalg.norm(items, axis=1, keepdims=True)
    return items / np.where(norms == 0, 1e-10, norms)


def load_base_data(scenario, data_root=None, *, trust_pickle=False):
    import numpy as np
    import torch
    scenario_name(scenario)
    path = Path(data_root or REPO_ROOT / 'preprocess_data') / f'{scenario}.pt'
    data = load_tensor_file(path, trust_pickle=trust_pickle)
    if not isinstance(data, dict) or not isinstance(data.get('matrix'), torch.Tensor):
        raise ValueError('input must be a dictionary containing a tensor named matrix')
    matrix = data['matrix']
    if matrix.ndim != 2 or matrix.shape[0] < 2 or matrix.shape[1] < 1:
        raise ValueError('matrix must have shape [models, items], at least two models and one item')
    if matrix.is_complex() or matrix.layout != torch.strided:
        raise ValueError('matrix must be a dense, real-valued tensor')
    matrix = matrix.detach().to(dtype=torch.float32, device='cpu')
    if not torch.isfinite(matrix).all().item():
        raise ValueError('matrix must contain only finite values')
    values = matrix.numpy()
    return {'Y': values, 'scenarios_position': {scenario: np.arange(values.shape[1])},
            'normalized_vectors': normalize_items(values)}


def validate_anchor_count(num_anchors, num_items):
    if isinstance(num_anchors, bool) or not isinstance(num_anchors, int) or not 1 <= num_anchors <= num_items:
        raise ValueError(f'num_anchors must be between 1 and {num_items}')


def validate_split(num_rows, split_size, *, training):
    minimum = 2 * split_size + 1 if training else split_size
    if split_size < 2 or num_rows < minimum:
        raise ValueError(f'need split_size >= 2 and at least {minimum} model rows; got {num_rows}')


def cluster_representatives(vectors, labels, centers):
    """One unique item per cluster, in cluster order; empty clusters have zero weight."""
    import numpy as np
    anchors = [None] * len(centers)
    weights = np.bincount(labels, minlength=len(centers)).astype(np.float32)
    for cluster, center in enumerate(centers):
        members = np.flatnonzero(labels == cluster)
        if len(members):
            nearest = np.argmin(np.sum((vectors[members] - center) ** 2, axis=1))
            anchors[cluster] = int(members[nearest])
    used = {anchor for anchor in anchors if anchor is not None}
    remaining = iter(i for i in range(len(vectors)) if i not in used)
    for cluster, anchor in enumerate(anchors):
        if anchor is None:
            anchors[cluster] = next(remaining)
    return anchors, weights


def validate_records(records):
    if not isinstance(records, list):
        raise ValueError('result payload must be a list')
    for index, record in enumerate(records):
        if not isinstance(record, dict):
            raise ValueError(f'result {index} must be a dictionary')
        try:
            mae = float(record['mae'])
            tau = float(record['kendalls_tau'] if 'kendalls_tau' in record else record['kendalltau'])
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f'result {index} has invalid metric fields') from exc
        if not math.isfinite(mae) or mae < 0 or math.isinf(tau) or (math.isfinite(tau) and not -1 <= tau <= 1):
            raise ValueError(f'result {index} has out-of-range metrics')
    return records


def load_results(path, *, trust_pickle=False):
    if not Path(path).exists():
        return []
    return validate_records(load_tensor_file(path, trust_pickle=trust_pickle))


def save_results(records, path):
    import torch
    validate_records(records)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.result-', suffix='.pt', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            torch.save(records, stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


@contextmanager
def result_lock(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lock = path.with_suffix('.lock')
    try:
        stream = lock.open('x', encoding='utf-8')
    except FileExistsError as exc:
        raise RuntimeError(f'result writer lock exists: {lock}; remove only after checking no run is active') from exc
    try:
        with stream:
            stream.write(str(os.getpid()))
        yield
    finally:
        lock.unlink()
