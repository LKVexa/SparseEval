"""SparseEval research methods."""
